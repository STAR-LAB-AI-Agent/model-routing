#!/usr/bin/env bash
# demo.sh —— 1 分钟演示视频脚本（离线 Mock 模式，无需 API Key）
# 用法: bash demo.sh
set -e
export USE_MOCK=1
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
rm -f logs/router.log

GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
say() { echo -e "${CYAN}$*${NC}"; }

say "=== [1] 列出已注册模型池 ==="
python -m router.cli models

say "=== [2] 意图① 选模型：简单问答 → 便宜快速 ==="
python -m router.cli route "用一段话解释相对论"

say "=== [3] 意图① 复杂推理 → 强模型 ==="
python -m router.cli route "请逐步推理并证明费马小定理"

say "=== [4] 意图① 长文本 → 大上下文 ==="
python -m router.cli route "总结：$(python -c "print('数据 '*1500)")"

say "=== [5] 意图② 调用模型（自动路由 + 返回 Token/成本/耗时）==="
python -m router.cli call "解释什么是模型路由" --json

say "=== [6] 意图③ 统计 / 成本展示 ==="
python -m router.cli call "识别这张图片内容" >/dev/null
python -m router.cli call "调用工具查天气" >/dev/null
python -m router.cli stats --from-log --json

say "=== [7] 统一入口 run.py（nanobot 调用方式）==="
python -c "from run import handle; print(handle('route: 解释相对论'))"
python -c "from run import handle; print(handle('stats'))"

say "=== [8] 测试套件 ==="
pytest tests/ -q
